from utils import *
from SqueezeformerEncoder import *
from TransformerDecoder import *
from SqueezeformerTransformerModel import *
from train import *
from test import *

def main():
    """"""
    train()
    # test()

if __name__=="__main__":
    """"""
    main()



